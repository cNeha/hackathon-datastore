if $evm.root['dialog_load_balancer_type'] == '2'
  $evm.object['visible'] = true
else
  $evm.object['visible'] = false
end
