#
# Description: <Method description here>
#
$evm.log("info", "BHP : Test Log Message")
exit MIQ_OK
